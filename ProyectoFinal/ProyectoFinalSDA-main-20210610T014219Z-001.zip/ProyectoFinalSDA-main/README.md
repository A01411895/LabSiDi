# ProyectoFinalSDA

Proyecto Final del Laboratorio de Sistemas Digitales Avanzados

Hemos estado pensando en un proyecto que tenga una aplicación real utilizando un sensor de temperatura, fue así como llegamos a la conclusión de hacer un sensor de temperatura para mantener un laboratorio en los grados ideales. También haremos uso de un servomotor, una pantalla LCD y un led RGB. El servomotor servirá para simbolizar un aire acondicionado que enfría o caliente dependiendo de la temperatura deseada, el LED RGB nos mostrará, con una luz verde o roja, si la temperatura se encuentra dentro o fuera del rango deseado y finalmente, la pantalla LCD indicará los grados. El desarrollo de este sensor nos ayudará, igualmente, a reforzar los conocimientos que hemos aprendido en nuestro curso, tanto de codificar como de implementar la lógica para hacer funcionar el sistema.
